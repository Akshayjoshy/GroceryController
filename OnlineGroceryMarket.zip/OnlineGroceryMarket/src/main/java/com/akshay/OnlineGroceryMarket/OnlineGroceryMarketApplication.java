package com.akshay.OnlineGroceryMarket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineGroceryMarketApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineGroceryMarketApplication.class, args);
	}

}
